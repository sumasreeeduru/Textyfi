from django.db import models

# Create your models here.
class wordmodel(models.Model):
    sentence=models.TextField()
    