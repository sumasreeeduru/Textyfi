from django.shortcuts import render
from .models import wordmodel
import requests

# Create your views here.
def home(request):
    return  render(request,'app/index.html')

def wordcounter(request):
    sentence=wordmodel.objects.all()
    if request.method == 'POST' and 'countbtn' in request.POST :
        res=request.POST
        sentence=res['sentence']
        res=requests.get('http://localhost:8000/api/wordcounter/'+ sentence)
        count=res.text
        temp={'sentence':sentence,'count':count}
    elif request.method == 'POST' and 'ratebtn' in request.POST:
        res = request.POST
        sentence = res['sentence']
        res = requests.get('http://localhost:8000/api/ratereview/' + sentence)
        rating = res.text
        temp={'rating':rating,'sentence':sentence,}
    elif request.method == 'POST' and 'sum' in request.POST:
        res=request.POST
        sentence=res['sentence']
        res=requests.get('http://localhost:8000/api/summaryView/'+ sentence)
        summ=res.text
        temp={'sentence':summ}
    elif request.method == 'POST' and 'texthand' in request.POST:
        res=request.POST
        sentence=res['sentence']
        res=requests.get('http://localhost:8000/media/outputs/output.pdf')
        temp={'sentence':sentence,'request':'http://127.0.0.1:8000/media/outputs/output.pdf'}
    else:
        temp={'count':0,'rating':0,'sentence':sentence}

    return render(request,'app/index.html',temp)

