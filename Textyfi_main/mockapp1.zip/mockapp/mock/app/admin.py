from django.contrib import admin
from .models import wordmodel
# Register your models here.
admin.site.register(wordmodel)